export class UserAnswerDto {
    answer: string;
    
    constructor(answer: string) {
        this.answer = answer;
    }
}
